<?php

$v="test";
 ?>