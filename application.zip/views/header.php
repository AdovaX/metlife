<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="images/favicon.png">
    <title><?php echo $title; ?></title>

    <link rel="stylesheet" href="<?php echo base_url();?>css/icon/et-line-font.css">
    <!-- reset CSS -->
    <link href="<?php echo base_url();?>css/reset.css" rel="stylesheet">
    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
    <!-- icon CSS -->
    <link href="<?php echo base_url();?>css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/Stroke-Gap-Icons.css" rel="stylesheet">

    <link href="<?php echo base_url();?>css/hover.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/jquery.fancybox.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/testimonial.css" rel="stylesheet">

    <!-- owl carousel CSS -->
    <link href="<?php echo base_url();?>css/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/owl.theme.css" rel="stylesheet">
    <!-- Main style CSS -->
    <link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
    <!-- Responsive CSS -->
    <link href="<?php echo base_url();?>css/responsive.css" rel="stylesheet">


    <script type="text/javascript" src="<?php echo base_url();?>js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>js/bootstrap.min.js"></script>
    <!-- New Addings -->
    <link href="<?php echo base_url();?>css/progressbar.css" rel="stylesheet">


    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
	<script src="style/js/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
	<![endif]-->
</head>

<body>

    <section class="loading-overlay">
        <div class="Loading-Page">
            <h1 class="loader">Loading...</h1>
        </div>
    </section>

    <div class="content-wrap">
        <div id="home" class="body-wrapper">
            <header class="full-header">
                <nav id="primary-menu" class="navbar style-1">
                    <div class="row">
                        <div class="container mobile-heading">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                    data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <div class="collapse navbar-collapse pull-right" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-left">
                                    <li>
                                        <a href="<?php echo base_url();?>Home" class="dropdown-toggle">Home</a> </li>
                                    <li>
                                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Health Insurance</a>
                                    </li>
                                    <li>
                                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">About Us</a>
                                    </li>
                                    <li>
                                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Contact Us</a>
                                    </li>
                                    <li>
                                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Sign In</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </nav>
            </header>