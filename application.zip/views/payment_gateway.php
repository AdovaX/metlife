
        <!-- End  Header -->

		<!-- Start Pages Title  -->

       	<div id="Contact" class="light-wrapper">
			<div class="container inner">
				<div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="Contact-Form">
                                <form class="leave-comment contact-form" autocomplete="on" id="contact-form"  name="contact-form" method="post" action="php/send.php">
                                    <fieldset>
                                        <div id="formstatus"></div>
                                        <div class="Contact-us">
                                            <div class="form-input col-md-6">
                                               <label class="docsupload-label">Card Payment</label>

                                            </div>
                                            <div class="form-input col-md-6 pay-gatewaydiv1">
                                                 <label class="" >Quote Number: 123456789</label>
                                            </div>
                                            <div class="form-input col-md-12 pay-gatewaydiv2">
                                                <input class="payment-gateinput" disabled type="text" id="subject" name="subject" placeholder="Payment Details">
                                            </div>
                                            <div class="form-input col-md-6 pay-gatewaydiv3">
                                               <label class="payment-gatelabel">Policy Holder Name</label>

                                            </div>
                                            <div class="form-input col-md-6 pay-gatewaydiv4">

                                              <label style="">Fawad Sheikh</label>
                                               </div>

                                            <div class="form-input col-md-6 pay-gatewaydiv3">
                                               <label class="payment-gatelabel">Product Name</label>

                                            </div>
                                            <div class="form-input col-md-6 pay-gatewaydiv4">
                                                <label style="">IBP Individual</label>

                                             </div>
                                             <div style="" class="form-input col-md-6 pay-gatewaydiv3" >
                                               <label class="payment-gatelabel">Total Premium Amount</label>

                                            </div>
                                            <div class="form-input col-md-6 pay-gatewaydiv4">
                                                 <label class="" style="" >AED 3225.00</label>

                                             </div>
                                               <div style="" class="form-input col-md-6 pay-gatewaydiv3" >
                                               <label class="payment-gatelabel">MetLife Policy Number</label>

                                            </div>
                                            <div class="form-input col-md-6 pay-gatewaydiv4">
                                                 <label class="pay-gatewaydiv3" >V269500</label>

                                             </div>
                                            <div class="form-input col-md-12 pay-gatewaydiv2">
                                                <input class="payment-gateinput" type="text" id="subject" name="subject" disabled placeholder="Credit/Debit Card Details">
                                            </div>
                                             <div class="form-input col-md-6">
                                             	<label class="payment-gatelabel">Full Name On Card</label>
                                                <input class="payment-gateinput1" type="text" id="name" name="name" placeholder="" >
                                            </div>
                                            <div class="form-input col-md-6">
                                               <label class="payment-gatelabel">Card Number</label>
                                                <input  class="payment-gateinput1" type="email" id="email" name="email" placeholder="" >
                                            </div>

                                            <div class="form-input col-md-6">
                                             	<label class="payment-gatelabel">CVV Number</label>
                                                <input class="payment-gateinput1" type="text" id="name" name="name" placeholder="" >
                                            </div>
                                            <div class="form-input col-md-6">
                                               <label class="payment-gatelabel">Card Expiry</label>
                                                <input class="payment-gateinput1" type="email" id="email" name="email" placeholder="" >
                                            </div>

                                           <div class="row">
                                            <div class="form-submit col-md-6">

                                            </div>
                                             <div class="form-submit col-md-6">
                                                <a href="Doc_upload" class="btn btn-primary btn-box" > Back </a>
<!--                                              	 <input type="submit" id="submit" class="btn btn-primary btn-box" value="Back">
 -->                                              <!-- <input type="submit" id="submit" class="btn btn-primary" value="Pay"> -->
         <a href="Receipt" class="btn btn-primary" > Pay </a>

                                            </div>
                                        </div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>
                    </div>

				</div>
			</div>
		</div>
		<!-- End Pages Title  -->

		<!-- Start Pricing Tables -->

