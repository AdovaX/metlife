
		<section id="Page-title" class="Page-title-Style2 section-top">

    			<div class="container ">
    			     <div class="big-banner" >
                </div><!--/.big-banner -->
			</div>
		</section>

        <section id="Why_Us">
            <div class="container inner">
                <div class="row">
                    <div class="col-md-6">
                        <div class="title-section text-left">
                            <h4>Welcome to MetLife Insurance</h4>

                        </div>


                    </div>
                    <div class="col-md-6">
                        <div class="title-section text-right">
                          <a href="#">If You Already Have a Quotation Number, click here</a>
                        </div>
                    </div>

                </div>
                <hr class="hrcolor">
            </div>

        </section>


		<div id="Pricing" class="light-wrapper">

			<div class="container inner-page">
				<!--Plans inner-->
				<div class="pricing">


					<div class="row">

          <div class="homepage-top"><h5>Select product specification</h5></div>
						<div class="col-sm-3 col-md-4">
							<div class="card pricing-col">
								<div class="pricing-header">
									<a class="thumbnail product_text" href="<?php echo base_url();?>Inoutform">
                        <img class="img-responsive productslisting-img" src="images/MetLife_product.png" alt="MetLife-Product">

                           </a>
								</div>

                 <div class="pricing-content">
                                 <a class="product_text" href="<?php echo base_url();?>Inoutform">
                                <p> <center  class="center_header">   EBP<br> Employee ON Company Visa/Domestic Help</center></p>
                                  <center class="center_text">This is an insurance plan that protects individuals whose visa is sponsored by their employer and is earning a monthly income of AED 4,000 and below.
                                        You also must have a valid  UAE residence visa except Abu Dhabi and Al Ain. Prices starts from AED 1000<a id="specification"> Click here</a> for quotes.
                                  </center>
                                </a>
                                </div>
								<!-- /.pricing-content -->
							</div>
							<!-- /.pricing-col-->
						</div>




						<div class="col-sm-3 col-md-4">
                            <div class="card pricing-col ">
                                <div class="pricing-header">
                                    <a class="thumbnail" href="<?php echo base_url();?>Inoutform">
                                      <img class="img-responsive productslisting-img" src="images/medicalcare.jpg" alt="MetLife-Product" >

                                      </a>
                                </div>
                                <!-- /.pricing-header -->

                                <div class="pricing-content productslisting">
                                 <a class="product_text" href="<?php echo base_url();?>Inoutform">
                                   <p> <center  class="center_header">   EBP<br> Dependent Visa</center></p>
                                  <center class="center_text">This is an insurance plan that protects individuals who is not earning an income and whose visa is sponsored by their  immediate family member.
                                      You also must have a valid UAE residence visa except Abu Dhabi and Al Ain. Prices starts from AED 1000<a href="#"> Click here</a> for quotes.
                                  </center>
                                </a>
                                </div>
                                <!-- /.pricing-content -->
                            </div>
                            <!-- /.pricing-col-->
                        </div>


                          <div class="col-sm-3 col-md-4">
                            <div class="card pricing-col ">
                                <div class="pricing-header">
                                  <a class="thumbnail" href="<?php echo base_url();?>Inoutform">
                                    <img class="img-responsive productslisting-img" src="images/student.jpg" alt="MetLife-Product" >
                                   </a>
                                </div>
                                <!-- /.pricing-header -->

                                <div class="pricing-content productslisting">
                                  <a class="product_text"  href="<?php echo base_url();?>Inoutform">
                                  <p>  <center  class="center_header">EBP<br> Student Visa</center></p>
                                 <center class="center_text">This is a group insurance plan that protects your employees with life insurance and disability coverage.
                                    You also must have a valid UAE residence visa except Abu Dhabi and Al Ain. Prices starts from AED 1000
                                    <a href="#">Click here </a>for quotes.
                                    </center>
                                  </a>
                                </div>
                                <!-- /.pricing-content -->
                            </div>
                            <!-- /.pricing-col-->
                        </div>
          					</div>
          					<!-- /.row -->
          				</div>


                <div id="protect_pricing" style="display: none;" class="products-productspricing"> Product Pricing</div>

               <table id="pricing_table" style="display: none;"  class="table table-bordered " cellpadding="20"  cellspacing ="20">
                  <thead>
                    <tr bgcolor="#05AED5"><th> </th><th colspan="6" align="center"> <b>For dependants (spouse, children or parents)</b></th></tr>
                    <tr bgcolor="#05AED5">
                      <th scope="col" class="head_text">#</th>
                      <th scope="col"  class="head_text" cell > <b>Child</b> <br>(From 0 to 18 years and 6 months) </th>
                      <th scope="col" class="head_text"><b>Male</b> <br>From 18 years7 months to 45 years and 6 months</th>
                      <th scope="col" class="head_text"><b>Female</b> <br>From 18 years7 months to 45 years and 6 months</th>
                      <th scope="col" class="head_text"><b>Male and Female</b> <br>From 45 years7 months to 60 years and 6 months</th>
                      <th scope="col" class="head_text"><b>Male and Female</b> <br>60 years and 7 months to 79 years and 6 months</th>
                      <th scope="col" class="head_text"><b>Male and Female</b> <br>79 years and 7 months and Above</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row" bgcolor="#05AED5">Premium<br>(AED)</th>
                      <td bgcolor="#a4ca9b">1,250.00</td>
                      <td bgcolor="#a4ca9b">1,900.00</td>
                      <td bgcolor="#a4ca9b">2,200.00</td>
                       <td bgcolor="#a4ca9b">2,500.00</td>
                        <td bgcolor="#a4ca9b">5,000.00</td>
                        <td bgcolor="#a4ca9b" rowspan="3">Strarting at AED 5,250.00 (Including VAT) subject to underwriting for final premium</td>
                    </tr>
                    <tr>
                      <th scope="row" bgcolor="#05AED5">VAT</th>
                       <td bgcolor="#a4ca9b">62.50</td>
                      <td bgcolor="#a4ca9b">95.00</td>
                      <td bgcolor="#a4ca9b">110.00</td>
                       <td bgcolor="#a4ca9b">125.00</td>
                        <td bgcolor="#a4ca9b">250.00</td>


                    </tr>
                    <tr>
                      <th scope="row" bgcolor="#05AED5">Premium<br>Including VAT</th>
                       <td bgcolor="#a4ca9b">1,312.50</td>
                      <td bgcolor="#a4ca9b">1,995.00</td>
                      <td bgcolor="#a4ca9b">2,310.00</td>
                       <td bgcolor="#a4ca9b">2,625.00</td>
                        <td bgcolor="#a4ca9b">5,250.00</td>


                    </tr>
                  </tbody>
                </table>

      </div>
      <!--End container-->
    </div>

