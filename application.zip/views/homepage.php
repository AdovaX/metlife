<section id="Page-title" class="Page-title-Style2 section-top">

<div class="container ">
<div class="big-banner">
</div>
</div>
</section>

<section id="Why_Us">
<div class="container inner">
<div class="row">
<div class="col-md-6">
<div class="title-section text-left">
<h4>Welcome to MetLife Insurance</h4>
</div>

</div>
<div class="col-md-6">
<div class="title-section text-right">
<a href="#">If You Already Have a Quotation Number, click here</a>
</div>


</div>

</div>
<hr class="hrcolor">
</div>

</section>

<div id="Pricing" class="light-wrapper">

<div class="container inner-page">
<!--Plans inner-->
<div class="pricing">


<div class="row">


<div class="col-sm-3 col-md-4">
<div class="homepage-top">
<h5>Select your preferred product</h5>
</div>
<div class="tab">
<a  class="btn btn-primary tab" href="<?php echo base_url();?>Products" >Individual (Essential Benefit Plan)</a>
</div>
<!-- /.pricing-col-->
</div>

<div class="col-sm-3 col-md-4">

</div>
<div class="col-sm-3 col-md-4">
<div class="tab">
<h5><b>Documents Required</b></h5>
<ul class="list" >
<li>Emirated ID Front Side</li>
<li>Emirated ID Back Side</li>
<li>Passport Front Side</li>
<li>Passport Back Side</li>
<li>Visa Page</li>
<li>Emirates ID Application</li>
<li>Member Passport Size Photo</li>
</ul>

</div>
<!-- /.pricing-col-->
</div>


</div>
<!-- /.row -->
</div>
<!-- /.pricing -->
<!--End plans inner-->
</div>
<!--End container-->
</div>