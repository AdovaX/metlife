
        <!-- End  Header -->

		<!-- Start Pages Title  -->

        <section id="Why_Us">
            <div class="container inner">
                <div class="row">
                    <ul class="checkout-bar progress_bar">

                    <li class="active">Policy Holder</li>

                    <li class="active">Member Additional Details</li>

                    <li class="active">Documents and Confirmation</li>

                    <li class="">Payment Options</li>


                	</ul>

                </div>
                <hr class="hrcolor">
            </div>

        </section>
 
		<div id="Pricing" class="light-wrapper">

			<div class="container inner-page">
				<!--Plans inner-->
				<div class="pricing">

					<div class="row">

                         <div class="detail-header">
			                <section class="content-header policy_holder_title">
			                    <h2><small></small></h1>
			                </section>
                             <div class="docsupload-div1">
			                 <div class="form-input col-md-3 docsupload-div2">
                                 <label class="docsupload-label">Summary Of Quote</label>

                             </div>
                             <div class="form-input col-md-3 docsupload-div3">
                                 <label class="docsupload-label" >Quote Number: <?php echo $quote_number;  ?></label>
                             </div>
                             <div class="form-input col-md-3 docsupload-div4">
                                 <label class="" >09-Feb-2020</label>
                             </div>
                              <div class="form-input col-md-3 docsupload-div5">
                                 <label class="docsupload-label">Quote Valid Till</label>
                             </div>
                            </div>

                             <div class="tablediv" >
                             <table class="table table-borderless">
							  <thead>
							    <tr bgcolor="#367fa9">
							      <th scope="col" class="docsupload-th">#</th>
							      <th scope="col" class="docsupload-th">Member To Insure</th>
							      <th scope="col" class="docsupload-th">Dependency</th>
							      <th scope="col" class="docsupload-th">Product</th>
							       <th scope="col" class="docsupload-th">Premium</th>
							    </tr>
							  </thead>
							  <tbody>
							  <?php foreach($view_all_members as $value){ ?>
							    <tr>
							      <th scope="row"><?php echo $value->member_id;?></th>
							      <td><?php echo $value->first_name;?></td>
							      <td><?php echo $value->relationship_to_policy_holder;?></td>
							      <td>Employee on company visa/Domestic Help</td>
							      <td>AED 1312.00</td> 
							    </tr> 
							  <?php } ?>
							    <tr  bgcolor="#367fa9">
							      <th scope="row" class="docsupload-th">Total</th>
							      <td colspan="3" class="docsupload-th">2</td>
							      <td class="docsupload-th">AED 3225.00</td>
							    </tr>
							  </tbody>
							</table>
							<span class="docsupload-span">DISCLAIMER :</span>

						</div>
						<div class="row docsupload-div6">

								 <input type="submit" id="agreetobuy" class="btn btn-primary btn-box docsupload-agree" value="Agree To Buy">

						</div>

                     	<div class="row" id="upload1" style="display: none;">
						<div class="col-md-8">
						<?php foreach($view_all_members as $users){ ?>


							<table class="table table-bordered">
							  <thead>
							    <tr>
							      <th scope="col"  bgcolor="#367fa9" class="docsupload-th">Member Name: <?php echo $users->first_name ?></th>
								   
							    </tr>
							  </thead>
							  <tbody>
							  <?php
							  foreach($Master_documet_titles as $value){ 
							  ?>
							    <tr>
							      <td class="docsupload-td"><?php echo $value->document_name;?></td>
							      <td  bgcolor="#367fa9" class="docsupload-th">
								  <input type="file" name="" value="" >
								  </td>
							      <td class="docsupload-td1"><b> </b></td><td class="docsupload-td2"> </td>
							    </tr> 
							  <?php 
							  }
							  ?>

							  </tbody>
							</table>
							<?php 
							}
							 ?>
							(Formats jpg,png,jpeg  File size max : 5mb)

						</div>

						<div class="col-md-4">

						</div>
                      </div>
                      <div class="row" id="upload2" style="display: none;"> 


					  <div class="col-md-8"  > </div>
						<div class="col-md-4"  >
                           <!-- <input type="submit" id="submit" class="btn btn-primary btn-box" value="Back"> -->
							<!--<input type="submit" id="submit" class="btn btn-primary" value="Continue to Payment"> -->
							<a href="member_details.html" class="btn btn-primary"> Back </a>
							<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Continue to Payment</button>

						</div>



			            </div><!-- /.detail-header -->


			           </div>

					</div>
					<!-- /.row -->
				</div>
				<!-- /.pricing -->
				<!--End plans inner-->
			</div>
			<!--End container-->
		</div>
		<!--End section content -->

		<!-- End Pricing Tables -->




<script type="text/javascript">
$(window).load(function(){

	$("#agreetobuy").click(function(){
  			$("#upload1").show();
        	$("#upload2").show();

	});
});



	   //  $('#gender').on('change', function() {
    //     var gender =  $('#gender :selected').val();
    //     if(gender=='F'){

    //     	$("#upload1").hide();
    //     	$("#upload2").hide();
    //     }
    // });


</script>


<!-- Trigger the modal with a button -->

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog ">

    <div class="modal-content">
      <div class="modal-header" style="padding:5px!important;">
        <label class=""  style="color:white;text-align:center;">Payment Method</label>
      </div>
      <div class="modal-body">
      	<div class="col-md-12">
      		<div class="col-md-6">

        <a href="<?php echo base_url();?>Payment_gateway" class="btn btn-primary" style="float: right;!important;" > Pay By Card </a>
    		</div>
              <div class="col-md-6">

        <a href="<?php echo base_url();?>Pay_by_cash" class="btn btn-primary" style="float: left!important;"> Pay By Cheque </a>
    </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>