
        <!-- End  Header -->

		<!-- Start Pages Title  -->

       	<div id="Contact" class="light-wrapper">
			<div class="container inner">
				<div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="Contact-Form">
                            	<div class="row">
                              <div class="col-sm-8">
                               <label class="paycash-label1">Pay By Check - Quote Number QT1234567899</label>
                               <div class="payCash">
                               	<label>Payment Details</label>
                               	<hr class="paycash-hr">

                                       <div class="form-input col-sm-2 paybycashfield">
                                               <label class="payment-gatelabel">Policy Holder Name</label>

                                        </div>
                                        <div class=" col-sm-2 paybycashlabel">
                                              <label style="">Fawad Sheikh</label>

                                        </div>
                                         <div class="form-input col-sm-2 paybycashfield">
                                               <label class="payment-gatelabel">Product Name</label>

                                        </div>
                                        <div class="form-input col-sm-2 paybycashlabel" style="">
                                              <label style="">EBP Individual</label>
                                        </div>
                                         <div class="form-input col-sm-2 paybycashfield">
                                               <label class="payment-gatelabel">Total Premium Amount</label>

                                        </div>
                                        <div class="form-input col-sm-2 paybycashlabel"style="">
                                              <label style="">AED 3225.00</label>
                                        </div>
                                        <div class="form-input col-sm-2 paybycashfield">
                                               <label class="payment-gatelabel">MetLife Policy Number</label>

                                        </div>
                                        <div class="form-input col-sm-2 paybycashlabel"style="">
                                              <label style="">V269500</label>
                                        </div>


                               </div>
                               <div class="paycash-div1">
                               	Important Note:
                               </div>
                               <div class="payCash" >
                                <p class="paycash-p1"> Member is requestd to go to one of the MetLife branch and make payment by cash. Post the receipt of payment confirmation and valid documents, the member policy will be activated.</p>

                                <p class="paycash-p2"> The turn around time for Policy activation is 15 working days from the payment receipt date provided all documents submitted are complete and valid. Members will be notified via their registered Email and Mobile number, you can get a copy of the original documnts from any of the MetLife branch which is nearest to you. </p>

                               </div>

                              </div>
                              <div class="col-sm-4 paycash-div2">

			                    <img src="images/conf.png" alt="MetLife-Product" class="paycash-img">


                              </div>
                          </div>
                               <div class="col-md-12">
                              	<p class="paycash-p3">Thank you  for choosing Metlife as yor insured partner. We will be happpy to serve you always. Click <a href="#">HERE</a> to branch list</p>
                                      <div class="paybycashbuttons">
                                       <a href="doc_upload" class="btn btn-primary btn-box" > Back </a>
<!--                                        <input type="submit" id="submit" class="btn btn-primary btn-box" value="Back">
 -->                                       <input type="submit" id="submit" class="paycashButtn" value="Print Receipt">
                                       <!-- <input type="submit" id="submit" class="paycashButtn" value="E-Mail Receipt"> -->
                                            <button type="button" class="paycashButtn" data-toggle="modal" data-target="#modalSubscriptionForm">E-Mail Receipt</button>

                                      </div>

                                 </div>
                            </div>
                        </div>
                    </div>

				</div>
			</div>
		</div>


<!-- Modal -->
<div class="modal fade" id="modalSubscriptionForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center" style="padding:15px!important;">
        <label class="modal-title w-100 font-weight-bold">E-Mail Receipt</label>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body mx-3">

        <div class="md-form mb-4">
          <i class="fa fa-envelope prefix grey-text"></i>
          <input type="email" id="form2" class="form-control validate">
          <label data-error="wrong" data-success="right" for="form2">Your email</label>
        </div>

      </div>
      <div class="modal-footer d-flex justify-content-center">
        <button class="btn btn-indigo">Send </button>
      </div>
    </div>
  </div>
</div>

