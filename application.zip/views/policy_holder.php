<section id="Why_Us">
    <div class="container inner">
        <div class="row">
            <ul class="checkout-bar progress_bar">

                <li class="active">Policy Holder Details</li>

                <li class="">Member Additional Details</li>

                <li class="">Documents and Confirmation</li>

                <li class="">Payment Options</li>
            </ul>
        </div>
        <hr class="hrcolor">
    </div>

</section>
<div id="Pricing" class="light-wrapper">

    <div class="container inner-page">
        <!--Plans inner-->
        <div class="pricing">

            <div class="row">

                <section class="content-header policy_holder_title">
                    <h2><small><b>Policy Holder Details</b></small></h2>
                </section><!-- /.content-header -->

                <form action="<?php echo base_url();?>policy_holder/data" method="post">
                    <?php echo validation_errors(); ?>
                    <?php echo form_open('form'); ?>

                    <section class="content">
                        <div class="box-body">
                            <div class="col-md-12">
                                <div class="form-group col-md-6">
                                    <label><span class="text-red">* </span>Company Name as per Visa</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-user"></i>
                                        </div>
                                        <?php echo form_input(['name'=>'policy_holder_name','id'=>'policy_holder_name','placeholder'=>'policy_holder_name','class'=>'form-control']);?>
                                    </div>
                                </div><!-- /.col-md-8 -->

                                <div class="form-group col-md-6">
                                    <label><span class="text-red">* </span>Policy Holder Email</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-envelope"></i>
                                        </div>
                                        <input value="" type="email" class="form-control" id="policy_holder_name"
                                            name="policy_holder_email" placeholder="" required>
                                    </div>
                                </div><!-- /.col-md-8 -->

                                <div class="form-group col-md-6">
                                    <label><span class="text-red">* </span>Policy Holder Mobile</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-phone"></i>
                                        </div>
                                        <input value="" type="text" class="form-control" id="policy_holder_name"
                                            name="policy_holder_mobile" placeholder="971-50-XXXXXXXX" required>
                                    </div>
                                </div><!-- /.col-md-8 -->
                                <div class="form-group col-md-6">
                                    <label><span class="text-red">* </span>Policy Holder's Passport Number</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-sort-numeric-asc"></i>
                                        </div>
                                        <input value="" type="text" class="form-control" id="policy_holder_name"
                                            name="policy_holder_passport" placeholder="E100001236541991" required>
                                    </div>
                                </div><!-- /.col-md-8 -->
                                <div class="form-group col-md-6">
                                    <label><span class="text-red">* </span>Policy Holder's Expiry Date on the
                                        Passport</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input value="" type="date" class="form-control" id="policy_holder_name"
                                            name="policy_holder_date" placeholder="" required>
                                    </div>
                                </div><!-- /.col-md-8 -->
                                <div class="form-group col-md-6">
                                    <label><span class="text-red">* </span>Policy Holder's Business and/or Residence
                                        Address</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-globe"></i>
                                        </div>

                                        <input value="" type="text" class="form-control" id="policy_holder_name"
                                            name="policy_holder_bussiness_address"
                                            placeholder="21 Park Street, PO Box 19878, Dubai" required>
                                    </div>
                                </div><!-- /.col-md-8 -->

                                <div class="form-group col-md-6">
                                    <label><span class="text-red">* </span>Policy Holder Emirates ID/Application
                                        Number</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-sort-numeric-asc"></i>
                                        </div>
                                        <input value="" type="text" class="form-control" id="policy_holder_emirates_id"
                                            name="policy_holder_emirates_id" placeholder="784-1986-XXXXXXX-X" required>
                                    </div>
                                </div><!-- /.col-md-8 -->

                                <div class="form-group col-md-6">
                                    <label><span class="text-red">* </span>Policy Holder UID Number (As per Visa
                                        Page)</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-sort-numeric-asc"></i>
                                        </div>
                                        <input value="" type="text" class="form-control" id="policy_holder_uid_no"
                                            name="policy_holder_uid_no" placeholder="" required>
                                    </div>
                                </div><!-- /.col-md-8 -->

                                <div class="form-group col-md-6">
                                    <label><span class="text-red">* </span>Visa Expiry Date</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input value="" type="date" class="form-control" id="visa_expiry_date"
                                            name="visa_expiry_date" placeholder="" required>
                                    </div>
                                </div><!-- /.col-md-8 -->

                                <div class="form-group col-md-6">
                                    <label><span class="text-red"></span>Policy Holder Address</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-globe"></i>
                                        </div>
                                        <input value="" type="text" class="form-control" id="policy_holder_address"
                                            name="policy_holder_address" placeholder="" required>
                                    </div>
                                </div><!-- /.col-md-8 -->
                                <div class="form-group col-md-12">
                                    <button type="button"
                                        class="btn btn-primary btn-box pt-10 pull-right pol-holder-btncancel"
                                        style="">Cancel</button>


                                    <button type="submit"
                                        class="btn btn-primary btn-box pt-10 pull-right pol-holder-btnnext">Next</button>

                                </div>
                            </div>
                        </div>
                    </section>
                    <?php echo  form_close();?>
                </form>
            </div>
        </div>
    </div>
</div>