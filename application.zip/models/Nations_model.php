<?php
class Nations_model extends CI_Model{

function get_nations(){ 

    $query = $this->db->get('mnt_nationalities');   
    return $query;
}

}
?>