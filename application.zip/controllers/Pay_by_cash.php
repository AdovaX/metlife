<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pay_by_cash extends CI_Controller {

	public function index()
	{
		$data['title']="MetLife - HTML Template for insurance";

		$this->load->view('header.php',$data);
		$this->load->view('pay_by_cash.php');
		$this->load->view('footer.php');
	}
}
