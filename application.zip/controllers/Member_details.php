<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member_details extends CI_Controller {
	public $quote_number;
	
	function __construct() {
        parent::__construct(); 
		$this->load->model('Nations_model');
		$this->load->model('Member_details_model');
		$this->quote_number=get_cookie('quote_number');
    }

	public function index()
	{
		$data['title']="MetLife - HTML Template for insurance";
		$data['quote_number'] =get_cookie('quote_number'); 
		$quote_number=$data['quote_number']; 
		$this->session->set_flashdata('quote_number', $data['quote_number']);  
		
		$config['nations']=$this->Nations_model->get_nations();

		$config['gender'] = array(
			'1' => 'Male',
			'2' => 'Female'
		);	
		$config['relation'] = array(
			'1' 	=> 'Applicant',
			'2' 	=> 'Employee',
			'3' 	=> 'Spouse',
			'4' 	=> 'Child',
			'5' 	=> 'Other'
		);	
		$config['marital_status'] = array(
			'1' => 'Married',
			'2' => 'Single'
		);

				// WORK EMIRATE
		$config['work_emirate'] = array(
			"1" => "DUBAI",
			"2" => "ABU-DHABI",
			"3" => "SHARJAH",
			"4" => "AJMAN",
			"5" => "RAS AL-KHAIMAH",
			"6" => "FUJAIRAH",
			"7" => "UMM AL-QUWAIN",
			"20" => "OTHERS"
		);
				// EMIRATE OF VISA
		$config['emirate_visa'] = array(
			"1" => "DUBAI",
			"2" => "ABU-DHABI",
			"3" => "SHARJAH",
			"4" => "AJMAN",
			"5" => "RAS AL-KHAIMAH",
			"6" => "FUJAIRAH",
			"7" => "UMM AL-QUWAIN",
			"8" => "AL AIN",
			"9" => "OTHERS",
			"10" => "OUTSIDE UAE",
			"11" => "UAE NATIONAL",
			"12" => "GCC NATIONAL",
			"13" => "DIPLOMAT",
			"14" => "NEW BORN",
			"15" => "DUBAI NATIONAL"
		); 

		// RESIDENCE EMIRATE
		$config['emirate_residency'] = array(
			"1" => "DUBAI",
			"2" => "ABU-DHABI",
			"3" => "SHARJAH",
			"4" => "AJMAN",
			"5" => "RAS AL-KHAIMAH",
			"6" => "FUJAIRAH",
			"7" => "UMM AL-QUWAIN",
		); 
		$data['errors'] =   $this->session->flashdata('errors');

		$this->load->view('header.php',$data);
		$this->load->view('member_details.php',$config);
		$this->load->view('footer.php');
	}
	function data()
	{    
		
		$quote_number=$this->quote_number;

		$member_id=$this->Member_details_model->get_Data($quote_number); 
		  
		$member_id = $member_id[0]->policy_holder_id;
		

		$this->form_validation->set_rules('first_name', 'first_name', 'required|trim');
		$this->form_validation->set_rules('country_of_residence', 'country_of_residence', 'required|trim');
		$this->form_validation->set_rules('second_name', 'second_name', 'required|trim');
		$this->form_validation->set_rules('emirates_id', 'emirates_id', 'required|trim');
		$this->form_validation->set_rules('last_name', 'last_name', 'required|trim');
		$this->form_validation->set_rules('eid_application_no', 'eid_application_no', 'required|trim');
		$this->form_validation->set_rules('gender', 'gender', 'required|trim');
		$this->form_validation->set_rules('dob', 'dob', 'required|trim');
		$this->form_validation->set_rules('uid_number', 'uid_number', 'required|trim');
		$this->form_validation->set_rules('marital_status', 'marital_status', 'required|trim');
		$this->form_validation->set_rules('relationship_to_policy_holder', 'relationship_to_policy_holder', 'required|trim');
		$this->form_validation->set_rules('passport_number', 'passport_number', 'required|trim');
		$this->form_validation->set_rules('nationality_id', 'nationality_id', 'required|trim');
		$this->form_validation->set_rules('applicant_email', 'applicant_email', 'required|trim');
		$this->form_validation->set_rules('salary', 'salary', 'required|trim');
		$this->form_validation->set_rules('residence_emirate', 'residence_emirate', 'required|trim');
		$this->form_validation->set_rules('work_emirate', 'work_emirate', 'required|trim');
		$this->form_validation->set_rules('member_mobile_number', 'member_mobile_number', 'required|trim');
		$this->form_validation->set_rules('emirate_visa', 'emirate_visa', 'required|trim');
		$this->form_validation->set_rules('file_number', 'file_number', 'required|trim');
		$this->form_validation->set_rules('eid_expiry_date', 'eid_expiry_date', 'required|trim');
		$this->form_validation->set_rules('member_registration_exp_date', 'member_registration_exp_date', 'required|trim');
		$this->form_validation->set_rules('business_residence_address', 'business_residence_address', 'required|trim');
		$this->form_validation->set_rules('height', 'height', 'required|trim');
		$this->form_validation->set_rules('weight', 'weight', 'required|trim'); 

		if ($this->form_validation->run()==FALSE) { 

			$this->session->set_flashdata('errors', validation_errors()); 
			return redirect('Member_details/index/'.$data['errors']); 

		}else{
			
  
			$data = array(
				'first_name' =>                 $this->input->post('first_name'),
				'second_name' =>                $this->input->post('second_name'),
				'last_name' =>                  $this->input->post('last_name'),
				'gender' =>                     $this->input->post('dob'),
				'dob' =>                        $this->input->post('dob'),
				'marital_status' =>             $this->input->post('marital_status'),
				'relationship_to_policy_holder' =>$this->input->post('relationship_to_policy_holder'),
				'nationality_id' =>             $this->input->post('nationality_id'),
				'salary' =>                     $this->input->post('salary'),
				'commision' =>                  0,
				'member_mobile_number' =>       $this->input->post('member_mobile_number'),
				'file_number' =>                $this->input->post('file_number'),
				'member_registration_id' =>     0,
				'mandatory_qns' =>              0,
				'residence_country_id' =>       $this->input->post('country_of_residence'),
				'eid_number' =>                 $this->input->post('emirates_id'),
				'eid_app_number' =>             $this->input->post('eid_application_no'),
				'uid_num' =>                    $this->input->post('uid_number'),
				'pp_num' =>                     $this->input->post('passport_number'),
				'applicant_email' =>            $this->input->post('applicant_email'),
				'residence_emirate_id' =>       $this->input->post('residence_emirate'),
				'work_emirate_id' =>            $this->input->post('work_emirate'),
				'visa_emirate_id' =>            $this->input->post('emirate_visa'),
				'eid_expiry_date' =>            $this->input->post('eid_expiry_date'),
				'pp_expiry_date' =>             $this->input->post('member_registration_exp_date'),
				'business_residence_address' => $this->input->post('business_residence_address'),
				'height' =>                     $this->input->post('height'),
				'weight' =>                     $this->input->post('weight'),
				'principle_id' =>               0,
				'policy_holder_id' =>           $member_id

				); 
				$this->Member_details_model->form_insert($data);
			
			redirect ( base_url().'Doc_upload');
			
		}
	}
}
