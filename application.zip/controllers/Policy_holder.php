<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Policy_holder extends CI_Controller {
	 function __construct() {
        parent::__construct();
		$data['title']="MetLife - HTML Template for insurance";
        $this->load->model('Policy_holder_model');


    }

	public function index()
	{
		$data['title']="MetLife - HTML Template for insurance";

		$this->load->view('header.php',$data);
		$this->load->view('policy_holder.php');
		$this->load->view('footer.php');
	}
	function data(){ 
        $this->form_validation->set_rules('policy_holder_name', 'policy holder name', 'required|trim'); 
		$this->form_validation->set_rules('policy_holder_email', 'policy holder email', 'required|trim|valid_email'); 
		$this->form_validation->set_rules('policy_holder_mobile', 'policy holder mobile', 'required|trim'); 
		$this->form_validation->set_rules('policy_holder_passport', 'policy holder passport', 'required|trim'); 
		$this->form_validation->set_rules('policy_holder_date', 'policy holder date', 'required|trim'); 
		$this->form_validation->set_rules('policy_holder_bussiness_address', 'policy holder bussiness address', 'required|trim'); 
		$this->form_validation->set_rules('policy_holder_emirates_id', 'policy_holder emirates id', 'required|trim'); 
		$this->form_validation->set_rules('policy_holder_uid_no', 'policy holder uid_no', 'required|trim'); 
		$this->form_validation->set_rules('visa_expiry_date', 'visa expiry date', 'required|trim'); 
		$this->form_validation->set_rules('policy_holder_address', 'policy holder address', 'required|trim');


		if ($this->form_validation->run()) {

			$data['policy_holder_name']=$this->input->post('policy_holder_name');
			$data['policy_holder_email']=$this->input->post('policy_holder_email');
			$data['policy_holder_mobile']=$this->input->post('policy_holder_mobile');
			$data['policy_holder_passport']=$this->input->post('policy_holder_passport');
			$data['policy_holder_date']=$this->input->post('policy_holder_date');
			$data['policy_holder_bussiness_address']=$this->input->post('policy_holder_bussiness_address');
			$data['policy_holder_emirates_id']=$this->input->post('policy_holder_emirates_id');
			$data['policy_holder_uid_no']=$this->input->post('policy_holder_uid_no');
			$data['visa_expiry_date']=$this->input->post('visa_expiry_date'); 
			$data['policy_holder_address']=$this->input->post('policy_holder_address'); 
			$data['quote_number']="QN" . mt_rand(10000000, 99999999);

			$this->session->set_flashdata('quote_number', $data['quote_number']); 
			$this->input->set_cookie('quote_number',$data['quote_number'],'3600'); 


			$data = array(
				'policy_holder_name' =>              $data['policy_holder_name'],
				'email' =>             $data['policy_holder_email'],
				'mobile' =>            $data['policy_holder_mobile'],
				'passport_number' =>          $data['policy_holder_passport'],
				'passport_expiry_date' =>              $data['policy_holder_date'],
				'business_residence_address' => $data['policy_holder_bussiness_address'],
				'emirates_id' =>       $data['policy_holder_emirates_id'],
				'uid_number' =>            $data['policy_holder_uid_no'],
				'visa_expiry_date' =>                $data['visa_expiry_date'],
				'policy_holder_address' =>           $data['policy_holder_address'],
				'quote_number' =>                    $data['quote_number']
				);

			$this->Policy_holder_model->form_insert($data);


			redirect ( base_url().'Member_details');

         }else{
            $data['title']="MetLife| Error";
			$data['errors'] = validation_errors();
			$this->load->view('header.php',$data);
			$this->load->view('policy_holder.php');
			$this->load->view('footer.php');

 
         }





	}
}